﻿#Requires AutoHotkey v2.0

Run(A_ScriptDir "\Images\Other\load.ahk")